navigator.cpuClass='x86';
