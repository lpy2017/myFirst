document.addEventListener('DOMContentLoaded', function() {
  if (window.PocoUpload) {
    document.all.PocoUpload.Document = document;
  }
}, false);