replaceSubElements(document);pageDOMLoaded=!0;needNotifyBar&&showNotifyBar();
