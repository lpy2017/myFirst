scriptConfig.none2block = true;
